<?php 

    $server = "localhost";
    $user = "root";
    $pass = "";
    $db = "rent";

    $conn = new mysqli($server,$user,$pass,$db);

    if($conn->connect_error){
        echo "<script>alert('Connection failed');</script>";
    }
    function alert($message){
        echo "<script>alert($message)</script>";
    }
?>