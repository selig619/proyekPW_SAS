<?php
    require_once("conn.php");
    session_start();

    $sql = "SELECT * FROM user";
    $result = $conn->query($sql);
    $users = $result->fetch_all(MYSQLI_ASSOC);

    if(isset($_POST["login"])){
        $email = $_POST["email"];
        $pass = $_POST["password"];

        if($email == "admin" && $pass =="admin"){
            $_SESSION["auth"] = "admin";
            header("location: admin.html");
        }
        else{
            $ada = false;
            foreach ($users as $key => $value) {
                if($value["email"] == $email || $value["phone"] == $email){
                    $ada = true;
                    if($pass == $value["password"]){
                        $_SESSION["auth"] = $value;
                        header("location: home.php");
                    }
                    else{
                        echo "<script>alert('Wrong Password!');</script>";
                    }
                }
            }
            if(!$ada){
                echo "<script>alert('Email not found!');</script>";
            }
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" ></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx"  crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link rel="stylesheet" href="plugin/aos.css">
    <link rel="stylesheet" href="plugin/index.css">
    <link rel="stylesheet" href="plugin/register.css">
    <link rel="stylesheet" href="fontawesome/css/all.min.css">
    <title>Document</title>
</head>
<body>
    
<nav class="navbar sticky-top navbar-expand-lg navbar-dark bg-dark sticky-top">
    <a class="navbar-brand offset-1" href="index.html">SAS Rent Car </a>
    <div class="col-5"></div>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor01"
        aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <!-- <form action="" method="post"> -->
        <div class="collapse navbar-collapse " id="navbarColor01">
            <ul class="navbar-nav ">
                <li class="nav-item ">
                    <a class="nav-link" href="index.html">HOME</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="aboutus.html">ABOUT</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="booking.html">BOOKING</a>
                </li>
            </ul>
            <div class="col-3"></div>
            <ul class="navbar-nav ">
                <li class="nav-item">
                    <a class="nav-link active" href="login.php">Login</a>
                </li>
                <li class="nav-item ">
                    <a class="nav-link" href="register.php">Register</a>
                </li>
            </ul>
        </div>
    <!-- </form> -->
</nav>

<!-- =============================================================  -->
<form action="" method="post">
<div class="coverLogin">
    <!-- FORM LOGIN -->
    <div class="conTengah">
        <h2 class="font-weight-bold">Login</h2>
        
        <div class="form-group">
            <label>Email / Phone Number</label>
            <input type="text" class="form-control" name="email">
        </div>
        <div class="form-group">
            <label>Password</label>
            <input type="password" class="form-control" name="password">
        </div>                
        
        <button type="submit" class="btn btn-dark btn-block" name="login">Login</button>   
    </div>
</div>
</form>


</body>
</html>