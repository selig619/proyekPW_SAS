<?php 
	$conn 	= mysqli_connect("localhost", "root", "","rent");


 ?>

 <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" ></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx"  crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link rel="stylesheet" href="plugin/index.css">
    <link rel="stylesheet" href="plugin/register.css">
    <link rel="stylesheet" href="fontawesome/css/all.min.css">
    <title>Document</title>
</head>
<body>

<nav class="navbar sticky-top navbar-expand-lg navbar-dark bg-dark sticky-top">
    <a class="navbar-brand offset-1" href="index.html">SAS Rent Car </a>
    <div class="col-5"></div>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor01"
        aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <!-- <form action="" method="post"> -->
        <div class="collapse navbar-collapse " id="navbarColor01">
            <ul class="navbar-nav ">
                <li class="nav-item ">
                    <a class="nav-link" href="index.html">HOME </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="aboutus.html">ABOUT</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="booking.html">BOOKING</a>
                </li>
            </ul>
            <div class="col-3"></div>
            <ul class="navbar-nav ">
                <li class="nav-item">
                    <a class="nav-link" href="login.php">Login</a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="register.php">Register</a>
                </li>
            </ul>
        </div>
    <!-- </form> -->
</nav>
<!-- ==================================================================  -->
<form action="" method="post">
<div class="coverInsert"> 

    <div class="conTengah" style="color: white; background-color: black">

        <h2 class="font-weight-bold">Insert Car</h2>
        <div class="form-group">
            <label>Plate Number</label>
            <input type="text" class="form-control" name="plate_number" id="plate_number" required>
        </div>
        <div class="form-group">
            <label>Type</label>
            <select id='cbtype' class="form-control" name="cbtype" onchange='ubahtype()'></select>
        </div>
        <div class="form-group">
            <label>Name</label>
            <select id='cbname' class="form-control" name="cbname" ></select>
        </div>
        <div class="form-group">
            <label>Year</label>
            <input  type="text" class="form-control" name="year" id="year">
        </div>
        <div class="form-group">
            <label>Color</label>
            <input  type="text" class="form-control" name="color" id="color" required>
        </div>
        <div class="form-group">
            <label>Fuel</label>
            <select name="fuel" id="fuel" class="form-control">
			  <option value="petrol">Petrol</option>
			  <option value="diesel">Diesel</option>
			</select>
        </div>                   
        
        <input type="button" class="btn btn-dark btn-block" value="Add Category" onclick="btninsert()">   
    </div>
</div>
</form>

<div id="kotakhasil"></div>

<script src="jquery.js"></script>
<script language="javascript">
	function btninsert(){
		alert('test');
		var plate_number= $("#plate_number").val();
		var cbtype	 	= $("#cbtype").val();
		var cbname 		= $("#cbname").val();
		var year 		= $("#year").val();
		var color 		= $("#color").val();
		var fuel 		= $("#fuel").val();
		

		$.post("ajax.php",
			{mode: "insertcar", plate_number: plate_number, cbtype: cbtype, cbname: cbname, year: year, color: color, fuel: fuel },
			function(result){
				alert('test');
			}
		);
	}
	function gettype(){
		$.post("ajax.php",
			{mode: "gettype"},
			function(result){
				alert(result);
				var arr = JSON.parse(result);
				var kal = "";
				kal = kal + "<option value='-'>-</option>"; 
				for(var i = 0; i < arr.length; i++){
					kal = kal + "<option value='" + arr[i]['id'] + "'>" + arr[i]['name'] + "</option>"; 
				}
				$("#cbtype").html(kal);
			}
		);
	}

	function ubahtype(){
		var kodetype = $("#cbtype").val(); 
		alert(kodetype); 
		$.post("ajax.php",
			{mode: "getname_bykodetype", kodetype: kodetype},
			function(result){
				alert(result);
				var arr = JSON.parse(result);
				var kal = "";
				for(var i = 0; i < arr.length; i++){
					kal = kal + "<option value='" + arr[i]['id'] + "'>" + arr[i]['name'] + "</option>"; 
				}
				$("#cbname").html(kal);
			}
		);
	}


gettype();
</script>

</body>
</html>