<?php 
	$conn 	= mysqli_connect("localhost", "root", "","rent");

	if($_POST['mode'] == "insertcar"){
		$plat 	= $_POST['plate_number'];
		$nama  	= $_POST['cbname'];
		$typecar= $_POST['cbtype'];
		$year	= $_POST['year'];
		$color	= $_POST['color'];
		$fuel	= $_POST['fuel'];
			
			mysqli_query($conn, "insert into cars values('$plat', '$nama', '$typecar', '$year', '$color', '$fuel')");
			echo "sukses";
		
	}
	if($_POST['mode'] == "gettype") {
		$qry = mysqli_query($conn, "select * from type"); 
		$arr = []; 
		while($row = mysqli_fetch_array($qry))
		{
			$arr[]  = $row; 
		}
		echo json_encode($arr); 
    }
    else if($_POST['mode'] == "getname_bykodetype") {
		$type 	= $_POST['kodetype']; 
		$arr = []; 
		$qry = mysqli_query($conn, "select * from car_name where type_id = '$type'"); 
		while($row = mysqli_fetch_array($qry)) {
			$arr[] = $row; 
		}
		echo json_encode($arr); 
	}
 ?>